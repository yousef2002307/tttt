<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## paymob

Create new account
https://accept.paymob.com/portal2/en/register
https://docs.paymob.com/


## controllers

copy paymob controller and change data as required
paymob controller
checkout controller


## env.file

copy env.example and add your paymob credentials
## Routes

add Routes same like web.php


## Setup Ngrok

setup ngrok.exe and follow go live steps


## Important Note

if you follow all the steps and the call back from paymob is success=false and pending = false please contact paymob support to active your integration




